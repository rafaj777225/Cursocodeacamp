$(window).on("scroll", function () {
  // Aquí deberás escribir la lógica que modificará la barra
  
});
